package com.cts.bookShopping.service;

import java.util.List;

import com.cts.bookShopping.bean.OrderDetails;

public interface OrderDetailsService {
	public String insertDetails(OrderDetails books);
	public  List<OrderDetails> displayDetails(String emailId);
	public String deleteOrderItem(int id);
}
