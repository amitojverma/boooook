package com.cts.bookShopping.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cts.bookShopping.bean.userRegistration;

@Repository("loginDAO")
public class LoginDAOImpl implements LoginDAO{

	@Autowired
	@Qualifier("sessionFactory")
	SessionFactory sessionFactory;
	@Transactional(readOnly=true)
	public userRegistration authenticate(String emailId, String password) {
		Session session = null;
		
		String query= "from userRegistration where emailId = ? AND password = ?";
	Query<userRegistration> query2=null;
		try {
			session = sessionFactory.getCurrentSession();
			query2=session.createQuery(query);
			query2.setParameter(0, emailId);
			query2.setParameter(1, password);
			userRegistration userRegistration = query2.getSingleResult();
			//System.out.println(userRegistration.getUserAddress());
			if(userRegistration==null)
				return null;
			else
				return userRegistration;
		} catch (Exception e) {
			e.printStackTrace();
		}
return null;
		
	}

}
