package com.cts.bookShopping.dao;

import java.util.List;

import com.cts.bookShopping.bean.Books;


public interface BooksDAO {
	public String insertBook(Books books);
	public String deleteBook(String id);
	public String updateBook(Books books);
	public Books  getBookById(String id);
	public List<Books> getAllBook();
	public Books getBookByName(String name);
	public List<Books> getDescBook();
	public List<Books> getAscBook();

}
