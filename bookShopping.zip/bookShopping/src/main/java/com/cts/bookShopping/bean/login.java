package com.cts.bookShopping.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity(name="login")
@Table(name = "login_table")
public class login {
	@Id
	@Column(name = "emailId")
	private String emailId;
	@Column(name = "password")
	private String password;
	@Override
	public String toString() {
		return "login [emailId=" + emailId + ", password=" + password + "]";
	}
	public login(String emailId, String password) {
		super();
		this.emailId = emailId;
		this.password = password;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public login() {
		// TODO Auto-generated constructor stub
	}

}
